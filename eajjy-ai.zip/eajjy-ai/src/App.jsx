import React from "react";
import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import Home from "./pages/Home.jsx";
import ServicesPage from "./pages/ServicesPage.jsx";
import UseCasesPage from "./pages/UseCasesPage.jsx";
import ProcessPage from "./pages/ProcessPage.jsx";
import FaqPage from "./pages/FaqPage.jsx";
import ProductPage from "./pages/ProductPage.jsx";
import WorkPage from "./pages/Work.jsx";
import HirePage from "./pages/HirePage.jsx";
import ContactPage from "./pages/ContactPage.jsx";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/use-cases" element={<UseCasesPage />} />
        <Route path="/process" element={<ProcessPage />} />
        <Route path="/faq" element={<FaqPage />} />
        <Route path="/product" element={<ProductPage />} />
        <Route path="/work" element={<WorkPage />} />
        <Route path="/hire" element={<HirePage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="*" element={<Home />} />
      </Route>
    </Routes>
  );
}
