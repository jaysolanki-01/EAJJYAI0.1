import React from "react";

const NAMES = ["Northwind", "Vertex&Co", "Lumio", "Halcyon", "Meridian", "Atlas Group"];

export default function ClientLogos() {
  return (
    <div className="logos reveal">
      <div className="wrap">
        <p>Powering automation for modern professional services firms</p>
        <div className="logo-row">{NAMES.map((n) => <span key={n}>{n}</span>)}</div>
      </div>
    </div>
  );
}
